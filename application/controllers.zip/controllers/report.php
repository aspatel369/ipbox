<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report extends CI_Controller {
function __construct() {
        parent::__construct();
        date_default_timezone_set('Asia/Calcutta');
        $this->load->model('report_model', 'report_model', TRUE);
        $this->load->model('global_pagination', 'global_pagination', TRUE);
        $this->load->library("session");
		 
}
	public function user_report()
	{	 
			$sessionValues = $this->session->userdata('logged_in');
            if ($this->session->userdata('logged_in')) { 

		    $getv = $this->input->get_post('q', TRUE); 

		    if($getv == 'dW5zZXQw'){ 

	   		if(@($this->session->userdata('student_id'))){
				 $this->session->unset_userdata('student_id');
	     		}
	      		if(@($this->session->userdata('from_date'))){
				$this->session->unset_userdata('from_date');
	      	}	
	      	if(@($this->session->userdata('to_date'))){
				$this->session->unset_userdata('to_date');
	      	}
	      	if(@($this->session->userdata('source'))){
				$this->session->unset_userdata('source');
	      	}
	      	if(@($this->session->userdata('status'))){
				$this->session->unset_userdata('status');
	      	}
	     }

	     if ($this->input->post('report_submit_data') == "Search") {
         	  $this->session->set_userdata('student_id', $this->input->post('student_id'));
              $this->session->set_userdata('from_date', $this->input->post('fromdate'));
            $this->session->set_userdata('to_date', $this->input->post('todate'));
              $this->session->set_userdata('source', $this->input->post('source'));            
              $this->session->set_userdata('status', $this->input->post('status'));            
        }

          $search['student_id'] = $this->session->userdata('student_id');
          $search['from_date'] = $this->session->userdata('from_date'); 
          $search['to_date'] = $this->session->userdata('to_date'); 
          $search['source'] = $this->session->userdata('source'); 
          $search['status'] = $this->session->userdata('status'); 
         	if($this->input->post('report_export_data') == "Export_to_Csv"){ 
			  $headers['header'] = array("Date and Time", "RollNumber","PhoneNumber","Source","Status","Duration");
			  
			$start = 0; 
			 $limit = $this->report_model->report_count($search);
			  $generateCsv  = $this->report_model->report_exportdetails($search); 
			  $result_array=array_merge($headers,$generateCsv); 
			  $filenamecsv = 'CDR_report'.date('d-M-y-H-i-s').'.csv';
			  array_to_csv($result_array,$filenamecsv);
			}
         $page_url = base_url() . "index.php/report/user_report";
          $total_users = $this->report_model->report_count($search);

		 $result_per_page = 25;
             $result_page = $this->global_pagination->index($page_url, $total_users, $result_per_page);
         $data['reportDetails'] = $this->report_model->get_report_Details($result_per_page,$result_page, $search);
		 // exit;
		 $data['source'] = $this->report_model->sourceDropDown();
		 $data['links'] = $this->pagination->create_links();
         $this->load->view('user_report',$data);		


			}
		else
		{
			redirect('admin/logout');
		}
	}

	public function house_report()
	{	 
			$sessionValues = $this->session->userdata('logged_in');
            if ($this->session->userdata('logged_in')) { 

		    $getv = $this->input->get_post('q', TRUE); 

		    if($getv == 'dW5zZXQw'){ 

			if(@($this->session->userdata('from_date'))){
				$this->session->unset_userdata('from_date');
	      	}	
	      	if(@($this->session->userdata('to_date'))){
				$this->session->unset_userdata('to_date');
	      	}
	      	if(@($this->session->userdata('house'))){
				$this->session->unset_userdata('house');
	      	}
	     }

	     if ($this->input->post('report_submit_data') == "Search") {
        // 	  $this->session->set_userdata('student_id', $this->input->post('student_id'));
              $this->session->set_userdata('from_date', $this->input->post('fromdate'));
            $this->session->set_userdata('to_date', $this->input->post('todate'));
              $this->session->set_userdata('house', $this->input->post('house'));            
           //   $this->session->set_userdata('status', $this->input->post('status'));            
        }

       //   $search['student_id'] = $this->session->userdata('student_id');
          $search['from_date'] = $this->session->userdata('from_date'); 
          $search['to_date'] = $this->session->userdata('to_date'); 
          $search['house'] = $this->session->userdata('house'); 
      //    $search['status'] = $this->session->userdata('status'); 
         	if($this->input->post('report_export_data') == "Export_to_Csv"){ 
			  $headers['header'] = array("Date and Time","Name","RollNumber","PhoneNumber","Source","Status","Duration");
			  
			$start = 0; 
			 $limit = $this->report_model->report_count_house($search);
			  $generateCsv  = $this->report_model->report_exportdetails_house($search); 
			  $result_array=array_merge($headers,$generateCsv); 
			  $filenamecsv = 'CDR_report'.date('d-M-y-H-i-s').'.csv';
			  array_to_csv($result_array,$filenamecsv);
			}
         $page_url = base_url() . "index.php/report/user_report";
          $total_users = $this->report_model->report_count_house($search);

		 $result_per_page = 25;
             $result_page = $this->global_pagination->index($page_url, $total_users, $result_per_page);
         $data['reportDetails'] = $this->report_model->get_report_Details_house($result_per_page,$result_page, $search);
		 // exit;
		 $data['house'] = $this->report_model->houseDropDown();
		// var_dump($data['source']);die;
		 $data['links'] = $this->pagination->create_links();
         $this->load->view('house_report',$data);		


			}
		else
		{
			redirect('admin/logout');
		}
	}

	public function userreport()
	{	 
	
		$this->load->view('user_report');	
	}
}
 
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
?>