<?php
 
class Students_Model extends CI_Model {
    
    public function __construct()
    {
        parent::__construct();
    }

    public function getData($id = "0") {
		$sql = "SELECT 	*
				FROM 	student s ";

		if($id > 0) {
			$sql .= " WHERE s.id = $id ";
		}

		$sql .= " ORDER BY s.id DESC ";

		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function insertOrUpdate($data) {
		$status = false;
		if(isset($data['id']) && $data['id'] > 0) {

			$id = $data['id'];
			unset($data['id']);

			$status = $this->db->where('id', $id)->update('student', $data);
		}
		else {
			$status = $this->db->insert('student', $data);
		}
		return $status;
	}

	public function delete($id) {
		$sql = "DELETE FROM student WHERE id = $id";
		return $this->db->query($sql);
	}
}