<?php if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Students extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Calcutta');
		$this->load->library("session");
        $this->load->model('Students_Model', 'Students_Model', TRUE);
    }

    public function index() {
		$data['data'] = $this->Students_Model->getData();
		$this->load->view('new/manage-students', $data);
	}

	public function saveDetails() {
		$formData = $this->input->post();

		$id = 0;
		if($formData['id'] > 0) {
			$id = $formData['id'];
		}

		$result = $this->Students_Model->insertOrUpdate($formData);
		if ($result) {
			if($id > 0) {
				$this->session->set_flashdata('msg', 'Record updated successfully');
			} else {
				$this->session->set_flashdata('msg', 'Record saved successfully');
			}
		} else {
			$this->session->set_flashdata('msg', 'Some error occurred!');
		}
		redirect('Students');
	}

	public function deleteRecord($id) {
		$result = $this->Students_Model->delete($id);
		if ($result) {
			$this->session->set_flashdata('msg', 'Record deleted successfully');
		} else {
			$this->session->set_flashdata('msg', 'Some error occurred!');
		}
		redirect('Students');
	}

	public function getDetails($id) {
		$data = $this->Students_Model->getData($id);
		echo json_encode($data[0]);
	}
}