<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	public function __construct() {
		
		parent::__construct();
		$this->load->library(array('session'));
		$this->load->helper(array('url'));
		$this->load->model('dashboard_model');

	}

	public function index()
	{
		$data['strength']=$this->dashboard_model->get_stats();
		$this->load->view('dashboard',$data);
	}
	public function callers()
	{
		$data['callers']=$this->dashboard_model->live_caller();
		$this->load->view('livecallers',$data);
	}

	public function home() {
		$this->load->view('new/dashboard');
	}
}
