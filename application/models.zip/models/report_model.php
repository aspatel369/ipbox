<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');

Class Report_model extends CI_Model {


function report_count($filter){

	$sql2="";
	$sql3="";
	$sql4="";
	$sql5="";

          if(!empty($filter['from_date'])){
		$fdate = $filter['from_date'];	      
	      if(!empty($filter['to_date'])){
		$tdate = $filter['to_date'];
				} 	
          }	
          if(@($filter['from_date']) && @($filter['to_date'])){				
			$sql2 = "AND date(call_datetime) BETWEEN '$fdate' AND '$tdate'";
			}

			if ($filter['student_id'] != "") {
                $roll = $filter['student_id'];
				 $sql3 = "AND student_id = '$roll'";
                }
          if ($filter['source'] != "") {
                $source = $filter['source'];
				 $sql4 = "AND source = '$source'";
                }

               if ($filter['status'] != "") {
               	if($filter['status'] == 'UNANSWERED'){
               	  $status = "";
				  $sql5 = "AND status = '$status'";

               	} else {
                $status = $filter['status'];
				 $sql5 = "AND status = '$status'";
				}
                }
        		
	  $sql = "SELECT COUNT(*)As cnt from call_report WHERE id!='' $sql2 $sql3 $sql4 $sql5 ORDER BY id DESC";
	$query = $this->db->query($sql);
	$row = $query->row();
     return $row->cnt;
     
}

function report_count_house($filter){

	$sql2="";
	$sql3="";
//	$sql4="";
	//$sql5="";

          if(!empty($filter['from_date'])){
		$fdate = $filter['from_date'];	      
	      if(!empty($filter['to_date'])){
		$tdate = $filter['to_date'];
				} 	
          }	
          if(@($filter['from_date']) && @($filter['to_date'])){				
			$sql2 = "AND date(call_datetime) BETWEEN '$fdate' AND '$tdate'";
			}

          if ($filter['house'] != "") {
                $house = $filter['house'];
				 $sql3 = "AND house = '$house'";
                }

        		
	  $sql = "SELECT COUNT(*)As cnt from v_cdr WHERE id!='' $sql2 $sql3 ORDER BY id DESC";
	$query = $this->db->query($sql);
	$row = $query->row();
     return $row->cnt;
     
}

function report_exportdetails($filter){
	$sql2="";
	$sql3="";
	$sql4="";
	$sql5="";

	     if(!empty($filter['from_date'])){
		$fdate = $filter['from_date'];	      
	      if(!empty($filter['to_date'])){
		$tdate = $filter['to_date'];
				} 	
          }	
          if(@($filter['from_date']) && @($filter['to_date'])){				
			$sql2 = "AND date(call_datetime) BETWEEN '$fdate' AND '$tdate'";
			}
			if ($filter['student_id'] != "") {
                $roll = $filter['student_id'];
				 $sql3 = "AND student_id like '$roll%'";
                }

            if ($filter['source'] != "") {
                $source = $filter['source'];
				 $sql4 = "AND source = '$source'";
                }

                if ($filter['status'] != "") {
               	if($filter['status'] == 'UNANSWERED'){
               	  $status = "";
				  $sql5 = "AND status = '$status'";

               	} else {
                $status = $filter['status'];
				 $sql5 = "AND status = '$status'";
				}
                }
	// With Spent Points	
	//$sql = "SELECT call_datetime,student_id,phone_number,source,status,duration,floor((time_to_sec(duration)/59)+1) as spentpoints from call_report WHERE id!='' $sql2 $sql3 $sql4 $sql5  ORDER BY id DESC";
	$sql = "SELECT call_datetime,student_id,phone_number,source,status,duration from call_report WHERE id!='' $sql2 $sql3 $sql4 $sql5  ORDER BY id DESC";
	$query = $this->db->query($sql);
	return $query->result_array();
}

function report_exportdetails_house($filter){
	$sql2="";
	$sql3="";
	$sql4 = "AND status = 'ANSWERED'";

	     if(!empty($filter['from_date'])){
		$fdate = $filter['from_date'];	      
	      if(!empty($filter['to_date'])){
		$tdate = $filter['to_date'];
				} 	
          }	
          if(@($filter['from_date']) && @($filter['to_date'])){				
			$sql2 = "AND date(call_datetime) BETWEEN '$fdate' AND '$tdate'";
			}
			if ($filter['house'] != "") {
                $houseid = $filter['house'];
				 $sql3 = "AND house = '$houseid%'";
                }

                

	$sql = "SELECT call_datetime,name,student_id,phone_number,source,status,duration from v_cdr WHERE id!='' $sql2 $sql3 $sql4 ORDER BY id DESC";
	$query = $this->db->query($sql);
	return $query->result_array();
}


function get_report_Details($limit, $start, $filter){
	$sql2="";
	$sql3="";
	$sql4="";
	$sql5="";

	     if(!empty($filter['from_date'])){
		$fdate = $filter['from_date'];	      
	      if(!empty($filter['to_date'])){
		$tdate = $filter['to_date'];
				} 	
          }	
         if(@($filter['from_date']) && @($filter['to_date'])){				
			$sql2 = "AND date(call_datetime) BETWEEN '$fdate' AND '$tdate'";
			}
			if ($filter['student_id'] != "") {
                $roll = $filter['student_id'];
				 //$sql3 = "AND student_id = '$roll'";
                $sql3 = "AND student_id like '$roll%'";
                }
         if ($filter['source'] != "") {
                $source = $filter['source'];
				 $sql4 = "AND source = '$source'";
                }

            if ($filter['status'] != "") {
               	if($filter['status'] == 'UNANSWERED'){
               	  $status = "";
				  $sql5 = "AND status = '$status'";

               	} else {
                $status = $filter['status'];
				 $sql5 = "AND status = '$status'";
				}
            }
			else {
            $status = 'ANSWERED';
			$sql5 = "AND status = '$status'";
			}

	 $sql = "SELECT DATE_FORMAT(call_datetime,'%d %b %h:%i %p') as dur, call_datetime,student_id,name,phone_number,source,duration,cost,status from v_cdr WHERE id!='' $sql2 $sql3 $sql4 $sql5 ORDER BY id DESC LIMIT " . $start . " ," . $limit;
	$query = $this->db->query($sql);
	return $query->result_array();
}

function get_report_Details_house($limit, $start, $filter){
	$sql2="";
	$sql3="";
	$sql4 = "AND status = 'ANSWERED'";
//	$sql5="";

	     if(!empty($filter['from_date'])){
		$fdate = $filter['from_date'];	      
	      if(!empty($filter['to_date'])){
		$tdate = $filter['to_date'];
				} 	
          }	
         if(@($filter['from_date']) && @($filter['to_date'])){				
			$sql2 = "AND date(call_datetime) BETWEEN '$fdate' AND '$tdate'";
			}
			if ($filter['house'] != "") {
                $houseid = $filter['house'];
				 //$sql3 = "AND student_id = '$roll'";
                $sql3 = "AND house = '$houseid%'";
                }
          

	 $sql = "SELECT DATE_FORMAT(call_datetime,'%d %b %h:%i %p') as call_datetime,student_id,phone_number,name,source,duration,cost,status from v_cdr WHERE id!='' $sql2 $sql3 $sql4 ORDER BY id DESC LIMIT " . $start . " ," . $limit;
	$query = $this->db->query($sql);
	return $query->result_array();
}


function sourceDropDown(){
        $sql = "SELECT distinct source from call_report";
	$query = $this->db->query($sql);
	return $query->result_array();
    }
	
function houseDropDown(){
        $sql = "SELECT id,house_name from house";
	$query = $this->db->query($sql);
	return $query->result_array();
    }


}
















