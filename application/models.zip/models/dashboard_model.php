<?php
 
class Dashboard_model extends CI_Model{
	private $table = 'v_student';
	private $callers = 'aster_live_calls';
	function __construct(){
	parent::__construct();
	}

public function get_stats(){
    $this->db->group_by('house_name');
	$this->db->select('house_name, count(*) strength,SUM( CASE WHEN STATUS =  \'Active\' THEN 1 ELSE 0 END )Active,SUM( CASE WHEN STATUS =  \'Inactive\' THEN 1 ELSE 0 END ) Inactive');
    $query = $this->db->get($this->table);
    return $query->result_array();
}
public function live_caller(){
	$this->db->select('answered_time,Case when TIMEDIFF(now(),answered_time) < \'02:00:00\' then TIMEDIFF(now(),answered_time) else \'00:00:00\' end as dur,v_student.name, student_id, phone_number, aster_live_calls.status',false);
    $this->db->from('aster_live_calls');
	$this->db->join('v_student', 'v_student.roll_no = aster_live_calls.student_id');
	$this->db->order_by('aster_live_calls.id', 'DESC');
	$query = $this->db->get();
	return $query->result_array();
}
public function live_count(){
    $this->db->select('count(*) as totalcalls');
    $this->db->from('aster_live_calls');
	//$this->db->join('v_student', 'v_student.roll_no = aster_live_calls.student_id');
	$query = $this->db->get();
    return $query->result_array();
}
}
